#include <stdio.h>
#include <stdlib.h>

int main() {
	int notes[30];
	int note_scannee = 0;
	char cas_spec = '0';
	for (int i = 0; i < 30; i++) {
		printf("Entrez la note numero %d\n", i+1);
		scanf("%d", &note_scannee);
		notes[i] = note_scannee;
		//V�rification des donn�es entr�es
		if (notes[i] < 0 || notes[i] > 20) {
			printf("Eleve absent? Ou voulez-vous arreter la saisie? A/O/N");
			scanf("%c", &cas_spec);
		}
		//Par convetion une note de -1 signifie une abscence
		if (cas_spec != '0') {
			if (cas_spec == 'A') {
				notes[i] = -1;
			}
			else {
				if (cas_spec == 'O') {
					break;
				}
				else {
					printf("Entrez la note numero %d\n", i + 1);
					scanf("%d", &note_scannee);
					notes[i] = note_scannee;
				}
			}
			cas_spec = '0';
		}
	}
	return(EXIT_SUCCESS);
}