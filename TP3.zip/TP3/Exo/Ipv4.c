#include <stdio.h>
#include <stdlib.h>

/*
* Une structure qui repr�sente une adresse r�seau logique en Ipv4
*/
typedef struct Adress {
	unsigned char MyAdress_w;
	unsigned char MyAdress_x;
	unsigned char MyAdress_y;
	unsigned char MyAdress_z;
}IpAdress;

/*
*  Une fonction qui retourne l'adresse du masque � partir du 
* nombre des bits � 1
*/
IpAdress mask_adress(int length) {
	IpAdress mask;
	// Pour l'instant seulement 
	mask.MyAdress_w = 255;
	mask.MyAdress_x = 255;
	mask.MyAdress_y = 255;
	mask.MyAdress_z = 0;
	return mask;
}

/*
*  Une fonction qui retourne l'adresse de diffusion � partir des adresses
* du masque et du host
*/
IpAdress broadcast_adress(IpAdress a, IpAdress mask) {
	IpAdress broad;
	broad.MyAdress_w = a.MyAdress_w | ~(mask.MyAdress_w);
	broad.MyAdress_x = a.MyAdress_x | ~(mask.MyAdress_x);
	broad.MyAdress_y = a.MyAdress_y | ~(mask.MyAdress_y);
	broad.MyAdress_z = a.MyAdress_z | ~(mask.MyAdress_z);
	return broad;
}

/*
*  Une fonction qui retourne l'adresse du r�seau � partir des adresses
* du masque et du host
*/
IpAdress reseau_adress(IpAdress a, IpAdress mask) {
	IpAdress reseau;
	reseau.MyAdress_w = a.MyAdress_w & mask.MyAdress_w;
	reseau.MyAdress_x = a.MyAdress_x & mask.MyAdress_x;
	reseau.MyAdress_y = a.MyAdress_y & mask.MyAdress_y;
	reseau.MyAdress_z = a.MyAdress_z & mask.MyAdress_z;
	return reseau;
}

/*
* Une fonction qu permet d'afficher l'adresse sous son format habituel
*/
void show_adress(IpAdress a){
	printf("%u.%u.%u.%u\n", a.MyAdress_w, a.MyAdress_x, a.MyAdress_y, a.MyAdress_z);
}


int main() {
	/*
	* Exemple 
	*/
	IpAdress local_adress = {192,168,129,10};
	int Ipv4MaskLength = 24;
	IpAdress mask = mask_adress(Ipv4MaskLength);
	IpAdress broad = broadcast_adress(local_adress, mask);
	IpAdress res = reseau_adress(local_adress, mask);
	show_adress(broad);
	show_adress(res);
	show_adress(mask);
	return(EXIT_SUCCESS);
}