#include <stdio.h>
#include <stdlib.h>

int main() {
	int nombre = 2868838400;
	int octets = sizeof(nombre);
	int bits = octets * 8;
	printf("%d octets sont utilises pour representer l'entier\n", octets);
	printf("%d bits sont utilises pour representer l'entier\n", bits);
	/*
	* Afficher l'�tat de tous les bits de nombre
	*/
	char* state;
	int j=1;
	for (int i = 0; i < bits; i++) {
		if (nombre & j) {
			state = "ON";
		}
		else {
			state = "OFF";
		}
		printf("bit %d: %s\n", i, state);
		j = j << 1;
	}

	printf("Bye!");
	return(EXIT_SUCCESS);
}
