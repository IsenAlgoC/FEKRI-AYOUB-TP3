#include <stdio.h>
#include <stdlib.h>

#define carre(x) x * x
#define carre2(x) (x) * (x)

int main() {
	int Nb = 5;
	printf("1: %d au carre est %d\n", Nb, carre(Nb));
	/*
	* Cette ligne de commande affiche 11 au lieu de 36
	* Le probl�me est que la gestion des macros se fait par copier coller
	* cad carre(Nb+1) ==> 5+1*5+1 le produit est prioritaire sur la somme donc
	* on aura carre(Nb+1) = carre(5+1) = carre(6) = 5+5+1 = 11
	* qui n'est pas le r�sultat attendu
	* Pour r�soudre ce probl�me on peut ajouter des parenth�ses autour des x
	* comme dans la macro carre2
	*/
	printf("1: %d au carre est %d\n", Nb+1, carre(Nb+1));
	/*
	* Resultat avec la deuxi�me macro
	*/
	printf("2: %d au carre est %d\n", Nb, carre2(Nb));
	printf("2: %d au carre est %d\n", Nb + 1, carre2(Nb + 1));
	return(EXIT_SUCCESS);
}